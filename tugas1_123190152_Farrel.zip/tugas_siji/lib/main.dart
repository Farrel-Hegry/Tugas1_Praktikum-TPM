import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("LOGIN SCREEN"),
        ),

        body: Center(
          child: Column(
            children:[

              Padding(
                padding: EdgeInsets.fromLTRB(0, 150, 0, 60),
                child:
                FlutterLogo(size: 50,),
              ),

              Container(
                width: 400,
                child: Column(
                  children: [
                    TextField(
                      decoration: InputDecoration(
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(40),
                        ),
                        hintText: "E-mail anda",
                        labelText: "E-mail",
                      ),
                    ),

                    SizedBox(
                      height: 10,
                    ),

                    TextField(
                      decoration: InputDecoration(
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(30),
                        ),
                        hintText: "Masukkan Password anda",
                        labelText: "Password",
                      ),
                    ),
                  ],
                ),
              ),

              Padding(
                padding: EdgeInsets.fromLTRB(0, 30, 0, 0),
                child: Column(
                  children:[

                    SizedBox(
                      width:400,
                      child:
                      ElevatedButton(onPressed: () {}, child: Text("Log In", style: TextStyle(fontSize: 17),)),
                    ),

                    TextButton(onPressed: (){}, child: Text("Forgot Password?", style: TextStyle(fontSize: 17, color: Colors.grey),)),
                  ],
                ),
              ),




            ],
          ),
        ),
      ),
    );
  }
}